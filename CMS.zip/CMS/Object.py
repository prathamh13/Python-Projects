class Object:
    def __init__(self, object_id, size, color):
        self.object_id = object_id
        self.size = size
        self.color = color
        self.bin_id = None
