'''
Python Code to implement a heap with general comparison function
'''

class Heap:
    '''
    Class to implement a heap with general comparison function
    '''
    
    def __init__(self, comparison_function, init_array):
        '''
        Arguments:
            comparison_function : function : A function that takes in two arguments and returns a boolean value
            init_array : List[Any] : The initial array to be inserted into the heap
        Returns:
            None
        Description:
            Initializes a heap with a comparison function
            Details of Comparison Function:
                The comparison function should take in two arguments and return a boolean value
                If the comparison function returns True, it means that the first argument is to be considered smaller than the second argument
                If the comparison function returns False, it means that the first argument is to be considered greater than or equal to the second argument
        Time Complexity:
            O(n) where n is the number of elements in init_array
        '''
        
        # Write your code here
        if len(init_array)==0:
            self.heap=[]
        else:
            self.heap=init_array
        
        self.comp=comparison_function
        for value in init_array:
            self.insert(value)
        
    def insert(self, value):
        '''
        Arguments:
            value : Any : The value to be inserted into the heap
        Returns:
            None
        Description:
            Inserts a value into the heap
        Time Complexity:
            O(log(n)) where n is the number of elements currently in the heap
        '''
        self.heap.append(value)
        self.heap_up(len(self.heap)-1)
        # Write your code here
        
    
    def extract(self):
        '''
        Arguments:
            None
        Returns:
            Any : The value extracted from the top of heap
        Description:
            Extracts the value from the top of heap, i.e. removes it from heap
        Time Complexity:
            O(log(n)) where n is the number of elements currently in the heap
        '''
        
        # Write your code here
        if len(self.heap)==0:
            print("heap is empty")
            return None
        else:
            self.swap(0,len(self.heap)-1)
            k=self.heap.pop()
            self.heap_down(0)
            return k
            
        
        
    
    def top(self):
        '''
        Arguments:
            None
        Returns:
            Any : The value at the top of heap
        Description:
            Returns the value at the top of heap
        Time Complexity:
            O(1)
        '''
        if len(self.heap)==0:
            print("heap is empty")
            return None
        else:
            
        
        
            return self.heap[0]
        
        # Write your code here
        
        
    def swap(self,r,l):
        self.heap[r],self.heap[l]=self.heap[l],self.heap[r]
    def heap_up(self,k):
        par=(k-1)//2
        if k>0 and self.comp(self.heap[k],self.heap[par]):
            self.swap(k,par)
            self.heap_up(par)
    def heap_down(self,s):
        o=(2*s)+1
        d=(2*s)+2
        key=s
        if o<len(self.heap) and self.comp(self.heap[o],self.heap[key]):
            key=o
        if d<len(self.heap) and self.comp(self.heap[d],self.heap[key]):
            key=d
        if key!=s:
            self.swap(s,key)
            self.heap_down(key)
        
    def is_empty(self):
        return len(self.heap) == 0
        
            
            
    
    # You can add more functions if you want to