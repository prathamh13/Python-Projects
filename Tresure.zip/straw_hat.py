'''
    This file contains the class definition for the StrawHat class.
'''

import crewmate
import heap
import treasure

class StrawHatTreasury:
    '''
    Class to implement the StrawHat Crew Treasury
    '''
    
    def __init__(self, m):
        '''
        Arguments:
            m : int : Number of Crew Mates (positive integer)
        Returns:
            None
        Description:
            Initializes the StrawHat
        Time Complexity:
            O(m)
            
        '''
        self.crewmates=[]
        for i in range(m):
            self.crewmates.append(crewmate.CrewMate(i))
        # Write your code here
        self.heap_crewmate=heap.Heap(comparison_function=lambda a,b:a.load<b.load,init_array=[])
        for CrewMate in self.crewmates:
            self.heap_crewmate.insert(CrewMate)
        
        self.treasures=[]
    
    def add_treasure(self, treasure):
        '''
        Arguments:
            treasure : Treasure : The treasure to be added to the treasury
        Returns:
            None
        Description:
            Adds the treasure to the treasury
        Time Complexity:
            O(log(m) + log(n)) where
                m : Number of Crew Mates
                n : Number of Treasures
        '''
        
        # Write your code here
        least_crm=self.heap_crewmate.extract()
        if least_crm.load>treasure.arrival_time:
            s_time=least_crm.load
        else:
            s_time=treasure.arrival_time
        
        completion_time=s_time+treasure.size
        least_crm.assign_treasure(treasure)
        treasure.completion_time=completion_time
        least_crm.load=completion_time
        self.heap_crewmate.insert(least_crm)
        self.treasures.append(treasure)
        
        
    
    def get_completion_time(self):
        '''
        Arguments:
            None
        Returns:
            List[Treasure] : List of treasures in the order of their ids after updating Treasure.completion_time
        Description:
            Returns all the treasure after processing them
        Time Complexity:
            O(n(log(m) + log(n))) where
                m : Number of Crew Mates
                n : Number of Treasures
        '''
        
        # Write your code here
        
        treasure_heap=heap.Heap(comparison_function=lambda a,b:a.id<b.id,init_array=[])
        for treasure in self.treasures:
            treasure_heap.insert(treasure)
        sorted_treasure=[]
        while not treasure_heap.is_empty():
            sorted_treasure.append(treasure_heap.extract())
        return sorted_treasure
    
    # You can add more methods if required