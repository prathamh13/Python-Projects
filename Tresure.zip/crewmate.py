'''
    Python file to implement the class CrewMate
'''

class CrewMate:
    '''
    Class to implement a crewmate
    '''
    
    def __init__(self,id):
        '''
        Arguments:
            None
        Returns:
            None
        Description:
            Initializes the crewmate
        '''
        self.id = id
        self.treasures = [] 
        self.load = 0       
    
    def assign_treasure(self, treasure):
        self.treasures.append(treasure)
        treasure.remaining_size = treasure.size 
        self.load += treasure.remaining_size

    def process_treasure(self, time):
        
        if self.treasures:
            treasure = self.treasures[0]
            treasure.remaining_size -= time
            if treasure.remaining_size <= 0:
                self.load -= treasure.size
                self.treasures.pop(0)
    
    # Add more methods if required