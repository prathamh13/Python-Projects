import random
from enum import Enum

class Strategy(Enum):
    ATTACK = 0
    BALANCED = 1
    DEFENCE = 2

# Outcome matrix: [Alice_strategy][Bob_strategy] = (p_win, p_draw, p_loss)
PROB_MATRIX = {
    Strategy.ATTACK: {
        Strategy.ATTACK: (0.5, 0.0, 0.5),
        Strategy.BALANCED: (0.7, 0.0, 0.3),
        Strategy.DEFENCE: (5/11, 0.0, 6/11)
    },
    Strategy.BALANCED: {
        Strategy.ATTACK: (0.3, 0.0, 0.7),
        Strategy.BALANCED: (1/3, 1/3, 1/3),
        Strategy.DEFENCE: (0.3, 0.5, 0.2)
    },
    Strategy.DEFENCE: {
        Strategy.ATTACK: (6/11, 0.0, 5/11),
        Strategy.BALANCED: (0.5, 0.5, 0.0),
        Strategy.DEFENCE: (0.1, 0.8, 0.1)
    }
}

class Bob:
    def __init__(self):
        self.last_result = None  # 'W', 'D', 'L'

    def play_move(self):
        if self.last_result == 'W':
            return Strategy.DEFENCE
        elif self.last_result == 'D':
            return Strategy.BALANCED
        elif self.last_result == 'L':
            return Strategy.ATTACK
        else:
            return random.choice(list(Strategy))

    def observe_result(self, result):
        self.last_result = result

class Alice:
    def __init__(self):
        self.strategy = Strategy.BALANCED

    def play_greedy(self, bob_strategy):
        max_ev = -1
        best_move = None
        for strat in Strategy:
            p_win, p_draw, p_loss = PROB_MATRIX[strat][bob_strategy]
            expected = p_win * 1 + p_draw * 0.5
            if expected > max_ev:
                max_ev = expected
                best_move = strat
        return best_move

    def play_random(self):
        return random.choice(list(Strategy))
