from player import PROB_MATRIX

def simulate_round(alice_strategy, bob_strategy):
    p_win, p_draw, p_loss = PROB_MATRIX[alice_strategy][bob_strategy]
    rand = random.random()
    if rand < p_win:
        return 'W'  # Alice wins
    elif rand < p_win + p_draw:
        return 'D'
    else:
        return 'L'
