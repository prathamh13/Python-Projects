from player import Alice, Bob
from game import simulate_round

def monte_carlo_simulation(rounds=1000, greedy=True):
    alice = Alice()
    bob = Bob()
    alice_points = 0
    outcomes = []

    for _ in range(rounds):
        bob_move = bob.play_move()
        if greedy:
            alice_move = alice.play_greedy(bob_move)
        else:
            alice_move = alice.play_random()

        result = simulate_round(alice_move, bob_move)
        bob.observe_result('L' if result == 'W' else 'W' if result == 'L' else 'D')
        if result == 'W':
            alice_points += 1
        elif result == 'D':
            alice_points += 0.5

        outcomes.append(result)

    return alice_points, outcomes
