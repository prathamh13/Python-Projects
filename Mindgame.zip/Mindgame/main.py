from monte_carlo import monte_carlo_simulation

if __name__ == "__main__":
    rounds = 100000

    points_greedy, _ = monte_carlo_simulation(rounds, greedy=True)
    points_random, _ = monte_carlo_simulation(rounds, greedy=False)

    print(f"Greedy strategy average points over {rounds} rounds: {points_greedy / rounds:.4f}")
    print(f"Random strategy average points over {rounds} rounds: {points_random / rounds:.4f}")
