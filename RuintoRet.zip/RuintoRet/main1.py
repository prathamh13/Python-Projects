from q1_classical_ruin import *
from q2_aggressive_bet import *
from q3_cursed_gambler import *
from q4_stock_chain import *

def test_all():
    print("Q1 Win Prob:", probability_win(0.4, 10, 3))
    print("Q1 Expected Rounds:", expected_rounds(0.4, 10, 3))

    print("Q2 Win Aggressive:", prob_win_aggressive(0.5, 16, 2))
    print("Q2 Expected Duration:", expected_duration_aggressive(0.5, 16, 2))

    print("Q3 Cursed Gambler:", cursed_gambler_expected_rounds(0.4, 0.6, 10, 5, 2, 3))

    p = [0.3] * 10 + [0]
    q = [0] + [0.3] * 10
    r = [0.4] * 11
    print("Q4 Stationary:", stationary_distribution(p, r, q))
    print("Q4 Hitting Time:", expected_hitting_time(p, r, q, 2, 5))

if __name__ == "__main__":
    test_all()
