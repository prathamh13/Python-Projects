MOD = 10**9 + 7

def modinv(b, m):
    return pow(b, m - 2, m)

def cursed_gambler_expected_rounds(p, q, k, m, W, t):
    dp = [0] * (k + 1)
    for i in range(t, k + 1):
        dp[i] = 0  # stop playing
    for i in range(k - 1, t - 1, -1):
        if m <= i <= m + W:
            dp[i] = 1 + p * dp[i + 1] + q * dp[i - 1]
        elif i > m + W:
            dp[i] = 1 + q * dp[i - 1]  # always loses
    a = round(dp[k] * (10**6))
    b = 10**6
    x = (a * modinv(b, MOD)) % MOD
    return x
