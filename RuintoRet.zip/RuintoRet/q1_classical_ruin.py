def probability_win(p, N, k):
    q = 1 - p
    if p == q:
        return k / N
    return (1 - (q / p)**k) / (1 - (q / p)**N)

def probability_infinite_wealth(p, k):
    if p <= 0.5:
        return 0
    return 1 - (1 - p) / p ** k

def expected_rounds(p, N, k):
    q = 1 - p
    if p == q:
        return k * (N - k)
    r = q / p
    numerator = (1 - r**k)*(1 - r**(N - k))
    denominator = (1 - r)**2 * (1 - r**N)
    return numerator / denominator
