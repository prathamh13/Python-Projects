def stationary_distribution(p, r, q):
    N = len(p) - 1
    pi = [1.0]
    for k in range(1, N + 1):
        pi_k = pi[-1] * p[k - 1] / q[k]
        pi.append(pi_k)
    total = sum(pi)
    return [x / total for x in pi]

def expected_hitting_time(p, r, q, a, b):
    N = len(p) - 1
    E = [0.0 for _ in range(N + 1)]
    for i in range(b - 1, a - 1, -1):
        E[i] = 1 + p[i] * E[i + 1] + r[i] * E[i] + q[i] * E[i - 1]
    return E[a]
