def prob_win_aggressive(p, N, k):
    def has_finite_binary(x):
        while x % 2 == 0:
            x //= 2
        return x == 1

    if k == 0:
        return 0
    if k == N:
        return 1

    prob = 1.0
    wealth = k
    while wealth < N:
        if wealth < N // 2:
            prob *= p
            wealth *= 2
        else:
            prob *= p
            wealth = N
    return prob

def expected_duration_aggressive(p, N, k):
    expected = 0
    wealth = k
    prob = 1.0
    while 0 < wealth < N:
        expected += prob
        if wealth < N // 2:
            prob *= p
            wealth *= 2
        else:
            prob *= p
            wealth = N
    return expected
