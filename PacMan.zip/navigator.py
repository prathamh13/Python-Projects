from maze import *
from exception import *
from stack import *
class PacMan:
    def __init__(self, grid : Maze) -> None:
        ## DO NOT MODIFY THIS FUNCTION
        self.navigator_maze = grid.grid_representation
        self.v={}
    def po(self,i,j):
        print("functip called")
        if (i>=len(self.navigator_maze) or j>=len(self.navigator_maze[0]) or self.navigator_maze[i][j]==1 or i<0 or j<0):
            print("if caled")
            return False
        elif(i<len(self.navigator_maze) and j<len(self.navigator_maze[0]) and i>=0 and j>=0):
            print("elif called")
            if(self.v[(i,j)]==False):
                return False
        else:
            print("else called")
            return True 
    
    
    def find_path(self, start : tuple, end : tuple) -> list:
        # IMPLEMENT FUNCTION HERE
        
        dumygrid=[]
        Stac=Stack()
        for i in range(len(self.navigator_maze)):
            dumygrid.append([])
            for j in range(len(self.navigator_maze[0])):
                self.v[(i,j)]=True
                dumygrid[-1].append(-1)
        Stac.push([start[0],start[1]])
        
        d=[[1,0],[0,-1],[-1,0],[0,1]]
        while Stac.s:
            
            p=Stac.pop()
            
            for i in d:
                
                # print(p[0]+i[0],p[1]+i[1])
                

                if((p[0]+i[0])<len(self.navigator_maze) and (p[1]+i[1])<len(self.navigator_maze[0]) and (p[0]+i[0])>=0 and (p[1]+i[1])>=0 and self.navigator_maze[p[0]+i[0]][p[1]+i[1]]==0 and self.v[(p[0]+i[0],p[1]+i[1])]==True ):
                    # print(i)
                    self.v[(p[0]+i[0],p[1]+i[1])]=False
                    Stac.push([p[0]+i[0],p[1]+i[1]])
                    
                    
                    if i[0]==1:
                        dumygrid[p[0]+i[0]][p[1]+i[1]]='D'
                    if i[0]==-1:
                        dumygrid[p[0]+i[0]][p[1]+i[1]]='U'
                    if i[1]==-1:
                        dumygrid[p[0]+i[0]][p[1]+i[1]]='L'
                    if i[1]==1:
                        dumygrid[p[0]+i[0]][p[1]+i[1]]='R'
                elif((p[0]+i[0])>=len(self.navigator_maze) or (p[1]+i[1])>=len(self.navigator_maze[0]) or self.navigator_maze[p[0]+i[0]][p[1]+i[1]]==1 or p[0]+i[0]<0 or p[1]+i[1]<0):
                    continue  
                elif((p[0]+i[0])<len(self.navigator_maze) and (p[1]+i[1])<len(self.navigator_maze[0]) and (p[0]+i[0])>=0 and (p[1]+i[1])>=0 and self.navigator_maze[p[0]+i[0]][p[1]+i[1]]==0):
                    if(self.v[(p[0]+i[0],p[1]+i[1])]==False):
                        continue 
        # for i in range(len(dumygrid)): print(dumygrid[i])
        if(dumygrid[end[0]][end[1]]==-1):
            
            raise PathNotFoundException
        else:
            p=[end[0],end[1]]
            ans=[]
            while p!=[start[0],start[1]]:
                ans.append([p[0],p[1]])
                if(dumygrid[p[0]][p[1]]=='D'):
                    p[0]-=1
                elif(dumygrid[p[0]][p[1]]=='L'):
                    p[1]+=1
                elif(dumygrid[p[0]][p[1]]=='U'):
                    p[0]+=1
                else:
                    p[1]-=1
                    
            ans.append([start[0],start[1]])
            
            k=[]
            for i in ans:
                t=(i[0],i[1])
                k.append(t)
            k.reverse()
            # print(k)
            return k
                
                
            
                    
        
                
        
