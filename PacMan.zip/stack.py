
class Stack:
    def __init__(self) -> None:
       self.s=[]
    def pop(self):
        return self.s.pop()
    def push(self,e):
        return self.s.append(e)
    def is_empty(self):
         if(len(self.s)==0):
             return self.s
    
        
        
    
        #YOU CAN (AND SHOULD!) MODIFY THIS FUNCTION
        
    
    
    # You can implement this class however you like